// WndCtrls.h : Declaration of the CWndCtrls

#ifndef __WNDCTRLS_H_
#define __WNDCTRLS_H_

#include "resource.h"       // main symbols
// *ATL requirements; taken from "StdAfx.h"
#if 1
#include <atlbase.h>
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;
#include <atlcom.h>
#endif
#include "Wnd_controls.h"
#include <commctrl.h>


/////////////////////////////////////////////////////////////////////////////
// CWndCtrls
class ATL_NO_VTABLE CWndCtrls : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CWndCtrls, &CLSID_WndCtrls>,
	public IDispatchImpl<IWndCtrls, &IID_IWndCtrls, &LIBID_WND_CONTROLSLib>
{
public:
	CWndCtrls()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_WNDCTRLS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CWndCtrls)
	COM_INTERFACE_ENTRY(IWndCtrls)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IWndCtrls
public:
	HRESULT FinalConstruct ();
	void FinalRelease ();

	STDMETHOD(Test)();

	STDMETHOD(ChooseWindowByName)(/*[in]*/ BSTR wnd_name);
	STDMETHOD(ChooseFocusedControl)();
	bool SendMessage_TVM_GETITEMW (TVITEMEXW& item);
	bool SendMessage_LVM_GETITEMW (LVITEMW& item);
	STDMETHOD(FocusSubwindowByName)(/*[in]*/ BSTR subwnd_name);
//	STDMETHOD(ChooseSubwindowByClassname)(/*[in]*/ BSTR class_name);
	STDMETHOD(ChooseSubwindowByNames)(/*[in]*/ BSTR class_name, /*[in]*/ BSTR window_name);
	STDMETHOD(ChooseMenuItemByName)(/*[in]*/ BSTR item_name);

	STDMETHOD(IsWindowVisible)(/*[out, retval]*/ BOOL* is_visible);

//	bool GetWindowClassName (HWND hwnd);
	bool ReadCheckState (LRESULT* state = 0);
	STDMETHOD(GetCheckboxState)(/*[out]*/ BOOL* state);
	STDMETHOD(SetCheckboxState)(/*[in]*/ BOOL state);
//	STDMETHOD(GetTreeViewItemImageIx)(/*[out]*/ DWORD* image_ix);
//	STDMETHOD(GetTreeViewItemImageIx)(/*[out]*/ long* image_ix);
	STDMETHOD(GetTreeViewItemImageIx)(/*[ref]*/ VARIANT* image_ix);
	STDMETHOD(GetListViewItemImageIx)(/*[ref]*/ VARIANT* image_ix);

private:
	HWND m_hwnd;
	DWORD m_thread_id;
	DWORD m_proc_id;
//// *is not really used
	HWND m_hwnd_child;
// *don't make a mess of HWNDs - we aren't such a complex script to have it
#if 0
// *is not really used
	HWND m_hwnd_ctrl;
// Choose/Find routines set it (but not use); test/Get routines do use it
	HWND m_hwnd_cur;
#endif
// *not in use
	HMENU m_hmenu;
};

#endif //__WNDCTRLS_H_
