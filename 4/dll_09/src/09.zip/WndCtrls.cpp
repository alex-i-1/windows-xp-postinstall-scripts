// WndCtrls.cpp : Implementation of CWndCtrls

#define WINVER 0x0501

//#include "stdafx.h"
#include "WndCtrls.h"


typedef unsigned int u32;


/////////////////////////////////////////////////////////////////////////////
// CWndCtrls


//CWndCtrls::CWndCtrls ()
HRESULT CWndCtrls::FinalConstruct ()
{
#if 0
	Beep (1000, 100);
	Sleep (100);
#endif
	m_hwnd = 0;
	m_thread_id = 0;
	m_proc_id = 0;
	m_hwnd_child = 0;
#if 0
	m_hwnd_ctrl = 0;
	m_hwnd_cur = 0;
#endif
	m_hmenu = 0;
     return S_OK;
}

//CWndCtrls::~CWndCtrls ()
void CWndCtrls::FinalRelease ()
{
#if 0
	Beep (2000, 100);
	Sleep (100);
#endif
}

STDMETHODIMP CWndCtrls::Test()
{
// convenient for the check of our availability
// *this is not intended to be disabled here, but disable (do not call) it in a script instead
#if 1
	Beep (10000, 100);
	Sleep (100);
#endif
	return S_OK;
}

// used for getting of HWND and thread id
STDMETHODIMP CWndCtrls::ChooseWindowByName(BSTR wnd_name)
{
// extra check
	if (m_hwnd)
	{
		Error ("Window handle already is set");
		return E_FAIL;
	}
	m_hwnd = FindWindowW (0, wnd_name);
	if (! m_hwnd)
	{
//		Error ("Failed to find window");
		Error ("Window not found");
		return E_FAIL;
	}

//	m_thread_id = GetWindowThreadProcessId (m_hwnd, 0);
	m_thread_id = GetWindowThreadProcessId (m_hwnd, &m_proc_id);
// undocumented, even now, 2013-01-27; but DDeBen has commented about it on MSDN page 2009-10-29, and it should be 0 in case of invalid hwnd
	if (! m_thread_id)
	{
		Error ("GetWindowThreadProcessId() failed");
		return E_FAIL;
	}

//	m_hwnd_cur = m_hwnd;

// looks like a various GetXxx will not help to get menu window (have menus a window(s) at all ?), so have to get the window's menu now
// *"If the window is a child window, the return value is undefined." - that's a bit inconvenient
	m_hmenu = GetMenu (m_hwnd);

	return S_OK;
}

STDMETHODIMP CWndCtrls::ChooseFocusedControl()
{
	BOOL B_r;
	GUITHREADINFO guithreadinfo = {0};

//	hwnd = GetFocus ();
	guithreadinfo.cbSize = sizeof(guithreadinfo);
	B_r = GetGUIThreadInfo (m_thread_id, &guithreadinfo);
	if (! B_r)
	{
		Error ("Failed to get GUI thread info");
		return E_FAIL;
	}

// extra check
// no need, we will call it multiple times
#if 0
	if (m_hwnd_child)
	{
		Error ("Control window handle already is set");
		return E_FAIL;
	}
#endif
// whole window; its name/text is on its caption
//	m_hwnd_child = guithreadinfo.hwndActive;
// *it still returns a parent window of a control (for example "SysTreeView32", WC_TREEVIEW) for me, and not the actual checkbox window
	m_hwnd_child = guithreadinfo.hwndFocus;
// whole window
//	m_hwnd_child = guithreadinfo.hwndCapture;
// whole window
//	m_hwnd_child = guithreadinfo.hwndMenuOwner;
// is 0 for menu
//	m_hwnd_child = guithreadinfo.hwndMoveSize;
// is 0 for menu
//	m_hwnd_child = guithreadinfo.hwndCaret;
	if (! m_hwnd_child)
	{
		Error ("Control window handle is 0");
		return E_FAIL;
	}

//	m_hwnd_cur = m_hwnd_child;

#if 0
	u32 i;
	char buf[256];
//	i = GetClassName (m_hwnd_child, buf, sizeof(buf));
	i = GetWindowText (m_hwnd_child, buf, sizeof(buf));
	Error (buf);
	return E_FAIL;
#endif

// try read the checkbox value
// (now working with "SysListView32"; take info from here, and remove this code away from here later)
#if 0
// _CheckMenuItem(hmenuPopup, FCIDM_VIEWSTATUSBAR, v_ShowControl(FCW_STATUS, SBSC_QUERY) == SBSC_SHOW);
// note also :
// CShellBrowser2::QueryStatus(CGID_ShellBrowser, FCIDM_GETSTATUSBAR)
// CShellBrowser2::IsControlWindowShown(FCW_STATUS, BOOL* pfShown)
// but I don't see any of 'CCommonBrowser' bases to be derived from 'IDispatch'; they mostly (or all) are derived from 'IUnknown', thus are useless to a script
#endif

	return S_OK;
}

// "SysTreeView32"
// send 'TVITEMEXW' to another process, inplacing a text buffer there, if 'TVIF_TEXT' flag is set
// *note, that here we don't watch for the correctness of the return, if an error has occured; only bother with the correctness when there is the processing goes by expectable way - no error
// good :  it is possible to get the text of the window this way
// checked :  item::iImage, item::iSelectedImage 0
// unchecked :  item::iImage, item::iSelectedImage 1
bool CWndCtrls::SendMessage_TVM_GETITEMW (TVITEMEXW& item)
{
	BOOL B_r;
	LRESULT LR;
	DWORD num_transfered;
	wchar_t* text_buf;
	u32 text_buf_size;
	bool with_text;
//	void* mem_there;
	void* item_there;
	void* text_buf_there;

	with_text = item.mask & TVIF_TEXT;

	HANDLE hproc;
	hproc = OpenProcess (PROCESS_ALL_ACCESS, 0, m_proc_id);
	if (! hproc)
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, OpenProcess failed");
		return 0;
	}

	if (with_text)
// inplace the buffer with another one, which is on the other side
	{
		text_buf = item.pszText;
		text_buf_size = item.cchTextMax * sizeof(item.pszText[0]);
		if (! text_buf_size)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, zero size of text buffer");
			return 0;
		}
		text_buf_there = VirtualAllocEx (hproc, 0, text_buf_size, MEM_COMMIT, PAGE_READWRITE);
		if (! text_buf_there)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, VirtualAllocEx failed");
			return 0;
		}
		item.pszText = (wchar_t*)text_buf_there;
		B_r = WriteProcessMemory (hproc, text_buf_there, text_buf, text_buf_size, &num_transfered);
		if (! B_r || num_transfered < text_buf_size)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, WriteProcessMemory failed");
			return 0;
		}
	}

	item_there = VirtualAllocEx (hproc, 0, sizeof(item), MEM_COMMIT, PAGE_READWRITE);
	if (! item_there)
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, VirtualAllocEx failed");
		return 0;
	}

	B_r = WriteProcessMemory (hproc, item_there, &item, sizeof(item), &num_transfered);
//	if (! B_r)
	if (! B_r || num_transfered < sizeof(item))
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, WriteProcessMemory failed");
		return 0;
	}

	LR = SendMessageW (m_hwnd_child, TVM_GETITEMW, 0, (LPARAM)item_there);

	B_r = ReadProcessMemory (hproc, item_there, &item, sizeof(item), &num_transfered);
//	if (! B_r)
	if (! B_r || num_transfered < sizeof(item))
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, ReadProcessMemory failed");
		return 0;
	}

	B_r = VirtualFreeEx (hproc, item_there, 0, MEM_RELEASE);
	if (! B_r)
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, VirtualFreeEx failed");
		return 0;
	}

	if (with_text)
	{
		u32 size;

		size = item.cchTextMax * sizeof(item.pszText[0]);
		if (size > text_buf_size)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, returned text buffer size is greater than we gave");
			return 0;
		}
		if (! size)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, zero size of returned text buffer");
			return 0;
		}

		B_r = ReadProcessMemory (hproc, text_buf_there, text_buf, size, &num_transfered);
		if (! B_r || num_transfered < size)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, ReadProcessMemory failed");
			return 0;
		}
//// ensure 0 ending
//		text_buf[size - 1] = 0;

		B_r = VirtualFreeEx (hproc, text_buf_there, 0, MEM_RELEASE);
		if (! B_r)
		{
			Error ("CWndCtrls::SendMessage_TVM_GETITEMW, VirtualFreeEx failed");
			return 0;
		}

// put back ptr to the given buffer of our side
		item.pszText = text_buf;
	}

	B_r = CloseHandle (hproc);
	if (! B_r)
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, CloseHandle failed");
		return 0;
	}

	if (! LR)
	{
		Error ("CWndCtrls::SendMessage_TVM_GETITEMW, TVM_GETITEM failed");
		return 0;
	}

	return 1;
}

// "SysListView32"
bool CWndCtrls::SendMessage_LVM_GETITEMW (LVITEMW& item)
{
	BOOL B_r;
	LRESULT LR;
	DWORD num_transfered;
	wchar_t* text_buf;
	u32 text_buf_size;
	bool with_text;
	void* item_there;
	void* text_buf_there;

	with_text = item.mask & LVIF_TEXT;

	HANDLE hproc;
	hproc = OpenProcess (PROCESS_ALL_ACCESS, 0, m_proc_id);
	if (! hproc)
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, OpenProcess failed");
		return 0;
	}

	if (with_text)
	{
		text_buf = item.pszText;
		text_buf_size = item.cchTextMax * sizeof(item.pszText[0]);
		if (! text_buf_size)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, zero size of text buffer");
			return 0;
		}
		text_buf_there = VirtualAllocEx (hproc, 0, text_buf_size, MEM_COMMIT, PAGE_READWRITE);
		if (! text_buf_there)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, VirtualAllocEx failed");
			return 0;
		}
		item.pszText = (wchar_t*)text_buf_there;
		B_r = WriteProcessMemory (hproc, text_buf_there, text_buf, text_buf_size, &num_transfered);
		if (! B_r || num_transfered < text_buf_size)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, WriteProcessMemory failed");
			return 0;
		}
	}

	item_there = VirtualAllocEx (hproc, 0, sizeof(item), MEM_COMMIT, PAGE_READWRITE);
	if (! item_there)
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, VirtualAllocEx failed");
		return 0;
	}

	B_r = WriteProcessMemory (hproc, item_there, &item, sizeof(item), &num_transfered);
	if (! B_r || num_transfered < sizeof(item))
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, WriteProcessMemory failed");
		return 0;
	}

	LR = SendMessageW (m_hwnd_child, LVM_GETITEMW, 0, (LPARAM)item_there);

	B_r = ReadProcessMemory (hproc, item_there, &item, sizeof(item), &num_transfered);
	if (! B_r || num_transfered < sizeof(item))
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, ReadProcessMemory failed");
		return 0;
	}

	B_r = VirtualFreeEx (hproc, item_there, 0, MEM_RELEASE);
	if (! B_r)
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, VirtualFreeEx failed");
		return 0;
	}

	if (with_text)
	{
		u32 size;

		size = item.cchTextMax * sizeof(item.pszText[0]);
		if (size > text_buf_size)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, returned text buffer size is greater than we gave");
			return 0;
		}
		if (! size)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, zero size of returned text buffer");
			return 0;
		}

		B_r = ReadProcessMemory (hproc, text_buf_there, text_buf, size, &num_transfered);
		if (! B_r || num_transfered < size)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, ReadProcessMemory failed");
			return 0;
		}

		B_r = VirtualFreeEx (hproc, text_buf_there, 0, MEM_RELEASE);
		if (! B_r)
		{
			Error ("CWndCtrls::SendMessage_LVM_GETITEMW, VirtualFreeEx failed");
			return 0;
		}

		item.pszText = text_buf;
	}

	B_r = CloseHandle (hproc);
	if (! B_r)
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, CloseHandle failed");
		return 0;
	}

	if (! LR)
	{
		Error ("CWndCtrls::SendMessage_LVM_GETITEMW, LVM_GETITEM failed");
		return 0;
	}

	return 1;
}

// unused
// *that is too much of work, for such a nonsense-project; use better 'ChooseFocusedControl()' instead
STDMETHODIMP CWndCtrls::FocusSubwindowByName(BSTR subwnd_name)
{
	LRESULT LR;

#if 1
	Error ("method unimplemented");
	return E_FAIL;
#endif

	if (! m_hwnd)
	{
		Error ("Parent window has not been set");
		return E_FAIL;
	}
#if 0
	Error (subwnd_name);
	return E_FAIL;
#endif
	m_hwnd_child = FindWindowExW (m_hwnd, 0, 0, subwnd_name);
#if 0
	if (m_hwnd_child)
		Error ("Control window found");
	else
		Error ("Control window not found");
	return E_FAIL;
#endif
	if (! m_hwnd_child)
	{
		Error ("Subwindow not found");
		return E_FAIL;
	}
#if 0
	u32 i;
	char buf[256];
	i = GetWindowText (m_hwnd_child, buf, sizeof(buf));
//	i = GetWindowText (m_hwnd_child, buf, sizeof(buf));
	Error (buf);
	return E_FAIL;
#endif

//	m_hwnd_cur = m_hwnd_child;

// this is some irrelevant to windows searching stuff, however, a treeview may also have a focused control in it
// look also CTreeCtrl::GetItemState(), TVIF_STATE, TVM_GETITEM
// or TVM_GETITEMSTATE
// or better TreeView_GetCheckState()

// works
//	LR = SendMessage (m_hwnd_child, TVM_SELECTITEM, TVGN_CARET, 0);

// works
	HTREEITEM hitem;
// works
	hitem = (HTREEITEM)SendMessage (m_hwnd_child, TVM_GETNEXTITEM, TVGN_CARET, 0);
// works
//	hitem = (HTREEITEM)SendMessage (m_hwnd_child, TVM_GETNEXTITEM, TVGN_ROOT, 0);
// fails
//	hitem = (HTREEITEM)SendMessage (m_hwnd_child, TVM_GETNEXTITEM, TVGN_PARENT, 0);
	if (! hitem)
	{
		Error ("TVM_GETNEXTITEM, TVGN_CARET failed");
		return E_FAIL;
	}
#if 0
	char buf[256];
	sprintf (buf, "items handle is %08x", hitem);
	Error (buf);
	return E_FAIL;
#endif

// works
#if 1
	LR = SendMessage (m_hwnd_child, TVM_GETCOUNT, 0, 0);
#if 0
	char buf[256];
	sprintf (buf, "items count is %u", LR);
	Error (buf);
	return E_FAIL;
#endif
#endif

#ifndef TVM_GETITEMSTATE
#define TVM_GETITEMSTATE        (TV_FIRST + 39)
#endif
// returns constant value :  2
//	LR = SendMessage (m_hwnd_child, TVM_GETITEMSTATE, (WPARAM)hitem, 0xffff);
// returns constant value :  2
//	LR = SendMessage (m_hwnd_child, TVM_GETITEMSTATE, (WPARAM)hitem, TVIS_STATEIMAGEMASK);
	LR = SendMessageW (m_hwnd_child, TVM_GETITEMSTATE, (WPARAM)hitem, TVIS_STATEIMAGEMASK);
#if 0
	char buf[256];
	sprintf (buf, "state bits are %08x", LR);
	Error (buf);
	return E_FAIL;
#endif

//	hitem = (HTREEITEM)0x02a7ec04;

#if 0
	hitem = (HTREEITEM)SendMessage (m_hwnd_child, TVM_GETNEXTITEM, TVGN_CHILD, (LPARAM)hitem);
	if (! hitem)
	{
		Error ("TVM_GETNEXTITEM, TVGN_CHILD failed");
		return E_FAIL;
	}
#endif

// doesn't work
#if 0
	SetLastError (0);

//	TVITEM item;
	TVITEMEX item = {0};
//	char buf[256] = {0};
//	char buf[256] = "abc";
	char buf[128] = "abc";
	item.hItem = hitem;
	item.mask |= TVIF_HANDLE;
//	item.mask |= TVIF_TEXT;
//	item.mask |= TVIF_STATE;
//	item.pszText = buf;
//	item.cchTextMax = sizeof(buf);
//	item.stateMask = TVIS_STATEIMAGEMASK;
	LR = SendMessage (m_hwnd_child, TVM_GETITEM, 0, (LPARAM)&item);
	if (! LR)
	{
//		Error ("TVM_GETITEM failed");
		DWORD D;
		D = GetLastError ();
		sprintf (buf, "TVM_GETITEM failed, error %u", D);
		Error (buf);
		return E_FAIL;
	}
// *don't use 'buf', it possibly was not used / was replaced !
	Error (item.pszText);
	return E_FAIL;
#endif
// doesn't work
#if 0
	SetLastError (0);

	TVITEMEXW item = {0};
	wchar_t buf[256] = {0};
	item.hItem = hitem;
//	item.mask |= TVIF_HANDLE;
#if 1
	item.mask |= TVIF_TEXT;
	item.pszText = buf;
//	item.cchTextMax = sizeof(buf);
	item.cchTextMax = sizeof(buf) / sizeof(buf[0]);
#else
	item.mask |= TVIF_STATE;
	item.stateMask = TVIS_STATEIMAGEMASK;
#endif
//	LR = SendMessageW (m_hwnd_child, TVM_GETITEM, 0, (LPARAM)&item);
	LR = SendMessageW (m_hwnd_child, TVM_GETITEMW, 0, (LPARAM)&item);
	if (! LR)
	{
//		Error ("TVM_GETITEM failed");
		DWORD D;
		D = GetLastError ();
		swprintf (buf, L"TVM_GETITEMW failed, error %u", D);
//		swprintf (buf, sizeof(buf) / sizeof(buf[0]), L"TVM_GETITEM failed, error %u", D);
		Error (buf);
		return E_FAIL;
	}
// *don't use 'buf', it possibly was not used / was replaced !
	Error (item.pszText);
	return E_FAIL;
#endif

//// good :  it is possible to get the text of the window this way
//// checked :  item::iImage, item::iSelectedImage 0
//// unchecked :  item::iImage, item::iSelectedImage 1
#if 0
#define ALLOC_SIZE 4096
	BOOL B_r;
	DWORD num_transfered;
	char mem_here[ALLOC_SIZE] = {0};
	void* mem_there;
	TVITEMEXW& item = *(TVITEMEXW*)mem_here;
	wchar_t* buf = (wchar_t*)(mem_here + sizeof(item));
	item.hItem = hitem;
	item.mask |= TVIF_HANDLE;
#if 1
	item.mask |= TVIF_TEXT;
//	item.pszText = buf;
//	item.cchTextMax = sizeof(buf);
//	item.cchTextMax = sizeof(buf) / sizeof(buf[0]);
#endif
#if 1
	item.mask |= TVIF_STATE;
// checkbox state is defined by the index of image
	item.stateMask = TVIS_STATEIMAGEMASK;
	item.stateMask = 0xffff;
#endif
#if 1
	item.mask |= TVIF_IMAGE;
	item.mask |= TVIF_PARAM;
	item.mask |= TVIF_SELECTEDIMAGE;
	item.mask |= TVIF_CHILDREN;
	item.mask |= TVIF_INTEGRAL;
#endif

	HANDLE hproc;
	hproc = OpenProcess (PROCESS_ALL_ACCESS, 0, m_proc_id);
	if (! hproc)
	{
		Error ("OpenProcess failed");
		return E_FAIL;
	}

	mem_there = VirtualAllocEx (hproc, 0, ALLOC_SIZE, MEM_COMMIT, PAGE_READWRITE);
	if (! mem_there)
	{
		Error ("VirtualAllocEx failed");
		return E_FAIL;
	}

	wchar_t* buf_there = (wchar_t*)((char*)mem_there + sizeof(item));
	item.pszText = buf_there;
	item.cchTextMax = (ALLOC_SIZE - sizeof(item)) / sizeof(buf_there[0]);
	B_r = WriteProcessMemory (hproc, mem_there, mem_here, ALLOC_SIZE, &num_transfered);
	if (! B_r)
	{
		Error ("WriteProcessMemory failed");
		return E_FAIL;
	}

//	LR = SendMessageW (m_hwnd_child, TVM_GETITEMW, 0, (LPARAM)&item);
	LR = SendMessageW (m_hwnd_child, TVM_GETITEMW, 0, (LPARAM)mem_there);

	B_r = ReadProcessMemory (hproc, mem_there, mem_here, ALLOC_SIZE, &num_transfered);
	if (! B_r)
	{
		Error ("ReadProcessMemory failed");
		return E_FAIL;
	}

	B_r = VirtualFreeEx (hproc, mem_there, 0, MEM_RELEASE);
	if (! B_r)
	{
		Error ("VirtualFreeEx failed");
		return E_FAIL;
	}

	B_r = CloseHandle (hproc);
	if (! B_r)
	{
		Error ("CloseHandle failed");
		return E_FAIL;
	}

	if (! LR)
	{
		Error ("TVM_GETITEM failed");
		return E_FAIL;
	}

#if 0
// *check that the 'buf' would not appear replaced (what is according to MSDN) !
	if (item.pszText != buf_there)
	{
		Error ("can't report window text - buffer address was changed");
		return E_FAIL;
	}
//	Error (item.pszText);
	Error (buf);
	return E_FAIL;
#endif
#if 0
//	swprintf (buf, L"state image index is %u", item.state >> 12);
	swprintf (buf, L"state is %08x", item.state);
	Error (buf);
	return E_FAIL;
#endif
#if 1
	swprintf (buf, L"item content :  %08x, %08x, %08x, %08x, %08x, %08x, %08x", item.state, item.stateMask, item.iImage, item.iSelectedImage, item.cChildren, item.lParam, item.iIntegral);
	Error (buf);
	return E_FAIL;
#endif
#endif

// another, shorter version
#if 1
	bool r;
	TVITEMEXW item = {0};
	wchar_t buf[256] = L"<unset>";

	item.hItem = hitem;
	item.mask |= TVIF_HANDLE;
#if 1
	item.mask |= TVIF_TEXT;
	item.pszText = buf;
//	item.cchTextMax = sizeof(buf);
	item.cchTextMax = sizeof(buf) / sizeof(buf[0]);
#endif
#if 1
	item.mask |= TVIF_STATE;
// checkbox state is defined by the index of image
	item.stateMask = TVIS_STATEIMAGEMASK;
	item.stateMask = 0xffff;
#endif
#if 1
	item.mask |= TVIF_IMAGE;
	item.mask |= TVIF_PARAM;
	item.mask |= TVIF_SELECTEDIMAGE;
	item.mask |= TVIF_CHILDREN;
	item.mask |= TVIF_INTEGRAL;
#endif

	r = SendMessage_TVM_GETITEMW (item);
	if (! r)
		return E_FAIL;

#if 0
//	Error (item.pszText);
	Error (buf);
	return E_FAIL;
#endif
#if 0
//	swprintf (buf, L"state image index is %u", item.state >> 12);
	swprintf (buf, L"state is %08x", item.state);
	Error (buf);
	return E_FAIL;
#endif
#if 1
	swprintf (buf, L"item content :  %08x, %08x, %08x, %08x, %08x, %08x, %08x", item.state, item.stateMask, item.iImage, item.iSelectedImage, item.cChildren, item.lParam, item.iIntegral);
	Error (buf);
	return E_FAIL;
#endif
#endif

	return S_OK;
}

bool RecurseFindChildWindowByNames (HWND& hwnd_child, HWND hwnd_parent, BSTR class_name, BSTR window_name)
{
	HWND hwnd;

// try this level
	hwnd = FindWindowExW (hwnd_parent, 0, class_name, window_name);
	if (hwnd)
	{
		hwnd_child = hwnd;
		return 1;
	}
// try recurse
	hwnd = 0;
	while (1)
	{
		bool r;
// get next window
		hwnd = FindWindowExW (hwnd_parent, hwnd, 0, 0);
		if (! hwnd)
			break;
// recurse
		r = RecurseFindChildWindowByNames (hwnd_child, hwnd, class_name, window_name);
		if (r)
			return 1;
	}

	return 0;
}

// *to give 0 'BSTR' from VBS, use 'vbNullString' ('0' is being converted to "0", and 'Null' gives "error: Type mismatch")
//STDMETHODIMP CWndCtrls::ChooseSubwindowByClassname(BSTR class_name)
STDMETHODIMP CWndCtrls::ChooseSubwindowByNames(BSTR class_name, BSTR window_name)
{
//	Sleep (10 * 1000);

// test
#if 0
	if (! class_name)
	{
		Error ("Class name is 0");
		return E_FAIL;
	}
#endif
#if 0
	if (! window_name)
	{
		Error ("Window name is 0");
		return E_FAIL;
	}
#endif

	if (! m_hwnd)
	{
		Error ("Parent window has not been set");
		return E_FAIL;
	}
#if 0
// *looks like it doesn't recurse
	m_hwnd_child = FindWindowExW (m_hwnd, 0, class_name, window_name);
	if (! m_hwnd_child)
#else
	bool r;
	r = RecurseFindChildWindowByNames (m_hwnd_child, m_hwnd, class_name, window_name);
	if (! r)
#endif
	{
//		Error ("Failed to find child window");
		Error ("Child window not found");
		return E_FAIL;
	}

// *only on the current thread
//	SetFocus (m_hwnd_child);
// *only on the current thread
//	SetActiveWindow (m_hwnd_child);
//	SetForegroundWindow (GetParent(m_hwnd_child));
	SetForegroundWindow (m_hwnd_child);

//	m_hwnd_cur = m_hwnd_child;

	return S_OK;
}

// unused
// fail :  tried to get up to "Status &Bar" item, but the menu of a folder has 0 items
STDMETHODIMP CWndCtrls::ChooseMenuItemByName(BSTR item_name)
{
//	u32 i;
//	wchar_t buf[256] = {0};
	wchar_t buf[256] = L"<unset>";
//	char bufa[256] = {0};
	char bufa[256] = "<unset>";

#if 1
// test
// gives 0. even though Spy shows this "ToolbarWindow32" window is being keeper of the menu
//	m_hmenu = GetMenu ((HWND)0x0037070c);

// #32768 (PopupMenu)
// *used for bar menus, file popup menus, and when clicking on an empty area with the right mouse button
// it has no child windows; its "child" (one more menu) is also of 8000 atom, and no name
	m_hwnd = FindWindowW ((LPCWSTR)0x8000, 0);
	if (! m_hwnd)
	{
		Error ("Explorer popup window not found");
		return E_FAIL;
	}

// 0
//#define MN_GETPPOPUPMENU 0x01EA
//	m_hmenu = (HMENU)SendMessage (m_hwnd, MN_GETPPOPUPMENU, 0, 0);

// 0
//	m_hmenu = GetMenu (m_hwnd);

	if (! m_hmenu)
	{
		Error ("Window menu handle has not been set");
		return E_FAIL;
	}

	u32 items_count;

	SetLastError (0);
	items_count = GetMenuItemCount (m_hmenu);
#if 0
	DWORD D;
	D = GetLastError ();
	sprintf (bufa, "error %u", D);
	Error (bufa);
	return E_FAIL;
#endif
#if 1
	swprintf (buf, L"items_count is %u", items_count);
	Error (buf);
	return E_FAIL;
#endif

//	GetSubMenu (m_hmenu, ix);

	BOOL B_r;
	MENUBARINFO menubarinfo = {0};
	menubarinfo.cbSize = sizeof(menubarinfo);
	B_r = GetMenuBarInfo (m_hwnd, OBJID_MENU, 0, &menubarinfo);
	if (! B_r)
	{
		Error ("GetMenuBarInfo() failed");
		return E_FAIL;
	}

// same as 'm_hmenu'
#if 0
	swprintf (buf, L"%08x %08x", m_hmenu, menubarinfo.hMenu);
	Error (buf);
	return E_FAIL;
#endif
// 0
#if 0
	swprintf (buf, L"%08x", menubarinfo.hwndMenu);
	Error (buf);
	return E_FAIL;
#endif
#if 0
	swprintf (buf, L"fbarfocused %u, ffocused %u", menubarinfo.fBarFocused, menubarinfo.fFocused);
	Error (buf);
	return E_FAIL;
#endif
// nothing
#if 0
	SetLastError (0);
	i = GetClassName (menubarinfo.hwndMenu, bufa, sizeof(bufa));
//	i = GetWindowText (menubarinfo.hwndMenu, bufa, sizeof(bufa));
//	i = GetClassName ((HWND)m_hmenu, bufa, sizeof(bufa));
//	i = GetWindowText ((HWND)m_hmenu, bufa, sizeof(bufa));
// ERROR_INVALID_WINDOW_HANDLE 1400L
#if 1
	DWORD D;
	D = GetLastError ();
	sprintf (bufa, "error %u", D);
#endif
	Error (bufa);
	return E_FAIL;
#endif

	Error ("didn't set the error");
	return E_FAIL;
#endif

	;

	return S_OK;
}

// unnecessary
//// and there is a bunch of work to check for BS_AUTOCHECKBOX, BS_CHECKBOX
#if 0
// *nope, need 'GetClassName()' instead
bool CWndCtrls::GetWindowClassName (HWND hwnd)
{
	BOOL B_r;
	WINDOWINFO wi = {0};

	if (! hwnd)
	{
		Error ("Control window handle has not been set");
		return 0;
	}
	wi.cbSize = sizeof(wi);
	B_r = GetWindowInfo (hwnd, &wi);
	if (! B_r)
	{
		Error ("Failed to get info on the control window");
		return 0;
	}

//	wi.atomWindowType;

	return 1;
}
#endif

// ==============================================================================

// *incorrect name, but we don't care
STDMETHODIMP CWndCtrls::IsWindowVisible(BOOL *is_visible)
{
	BOOL B_r;
	WINDOWINFO wi = {0};

// *there is 'IsWindowVisible()', but it doesn't return error state
	wi.cbSize = sizeof(wi);
	B_r = GetWindowInfo (m_hwnd_child, &wi);
	if (! B_r)
	{
		Error ("CWndCtrls::IsWindowVisible(), GetWindowInfo() failed");
		return E_FAIL;
	}

	*is_visible = !! (wi.dwStyle & WS_VISIBLE);

	return S_OK;
}

// ==============================================================================

//// *unused
bool CWndCtrls::ReadCheckState (LRESULT* state)
//bool CWndCtrls::ReadCheckState (LRESULT* state, HWND hwnd)
//bool CWndCtrls::ReadCheckState (LRESULT& state)
{
//	BOOL B_r;
//	LONG L;
	LRESULT LR;

	if (! m_hwnd_child)
	{
		Error ("Control window handle has not been set");
		return 0;
	}

// no, not by style
#if 0
	L = GetWindowLong (m_hwnd_child, GWL_STYLE);

	switch (L & 0x1f)
	{
	case BS_AUTOCHECKBOX:
	case BS_AUTORADIOBUTTON:
	case BS_AUTO3STATE:
	case BS_CHECKBOX:
	case BS_RADIOBUTTON:
	case BS_3STATE:
		break;
	default:
		Error ("Can't read check-state of this control :  it is not a button");
		return 0;
	}
#endif
#if 1
	u32 i;
	wchar_t buf[256];
	i = GetClassNameW (m_hwnd_child, buf, sizeof(buf) / sizeof(*buf));
	if (! i)
	{
		Error ("Failed to get classname of the control window");
		return 0;
	}
// "This function cannot retrieve the text of an edit control in another application." - for me it does/can
//	i = GetWindowText (m_hwnd_child, buf, sizeof(buf));
#if 0
	Error (buf);
	return 0;
#endif
#define BUTTON_CLASS_NAME L"Button"
	i = wcscmp (buf, BUTTON_CLASS_NAME);
	if (i)
	{
		swprintf (buf, L"Class of the control window is not \"%s\"", BUTTON_CLASS_NAME);
		Error (buf);
		return 0;
	}
#endif

//	A(state);
	LR = SendMessage (m_hwnd_child, BM_GETSTATE, 0, 0);
	if (state)
		*state = LR;

	return 1;
}

// *unused
STDMETHODIMP CWndCtrls::GetCheckboxState(BOOL *state)
{
#if 0
	Error ("method unimplemented");
	return E_FAIL;
#endif

	bool r;
	LRESULT st;

//	Beep (5000, 100);

	if (! m_hwnd_child)
	{
		Error ("Control window handle has not been set");
		return 0;
	}

	r = ReadCheckState (&st);
	if (! r)
		return E_FAIL;

#if 0
// *I think this is possible
	if (! state)
	{
		Error ("'state' variable required");
		return E_FAIL;
	}
#else
//	A(state);
#endif
// *that '3' vaguely was in 'BM_GETSTATE' MSDN 2005, but it is not there anymore; although could just use 'BM_GETCHECK' instead
	*state = (st & 3) == BST_CHECKED;

// test
#if 0
	char buf[256];
	sprintf (buf, "state is %u", st);
	Error (buf);
	return E_FAIL;
#endif

	return S_OK;
}

//// *unused
STDMETHODIMP CWndCtrls::SetCheckboxState(BOOL state)
{
#if 0
	Error ("method unimplemented");
	return E_FAIL;
#endif

	bool r;
	LRESULT LR;

	if (! m_hwnd_child)
	{
		Error ("Control window handle has not been set");
		return 0;
	}

// do a test - is it a checkbox control window
#if 0
	r = ReadCheckState ();
#else
	LRESULT st;
	r = ReadCheckState (&st);
#endif
	if (! r)
		return E_FAIL;

	HWND hwnd;
#if 0
	LR = SendMessage (m_hwnd_child, BM_SETCHECK, state ? BST_CHECKED : BST_UNCHECKED, 0);
#endif
	hwnd = m_hwnd_child;
//	hwnd = GetParent (m_hwnd_child);
// "Desktop icons" completely ignores this
#if 0
// '='/'-'
	LR = SendMessage (hwnd, WM_KEYDOWN, state ? 0x000000bb : 0x000000bd, state ? 0x000d0001 : 0x000c0001);
	LR = SendMessage (hwnd, WM_CHAR, state ? 0x0000003d : 0x0000002d, state ? 0x000d0001 : 0x000c0001);
	LR = SendMessage (hwnd, WM_KEYUP, state ? 0x000000bb : 0x000000bd, state ? 0xc00d0001 : 0xc00c0001);
#endif
// uhoh, only this works with "Desktop icons" (as it also doesn't receive +/- from a keyboard)
#if 1
// space bar
	if (((st & 3) == BST_CHECKED) != state)
	{
		LR = SendMessage (hwnd, WM_KEYDOWN, 0x00000020, 0x00390001);
		LR = SendMessage (hwnd, WM_CHAR, 0x00000020, 0x00390001);
		LR = SendMessage (hwnd, WM_KEYUP, 0x00000020, 0xc0390001);
	}
#endif

	return S_OK;
}


// *I am omiting 'Focused'/'Current' in the name of this function, because I am dropping the idea to make all this code correct, because the idea behind it is incorrect, and it have not to exist at all
// done by :  http://stackoverflow.com/questions/966767/passing-classic-asp-vbscript-parameters-byref-to-com-c?rq=1
// could return the value as it is done normally - by [out, retval]; but I am not searching for easy ways :)
//STDMETHODIMP CWndCtrls::GetTreeViewItemImageIx(DWORD *image_ix)
//STDMETHODIMP CWndCtrls::GetTreeViewItemImageIx(long *image_ix)
STDMETHODIMP CWndCtrls::GetTreeViewItemImageIx(VARIANT *image_ix)
{
	bool r;
//	LRESULT LR;
	TVITEMEXW item = {0};
	wchar_t buf[256] = L"<unset>";
	HTREEITEM hitem;

	if (! m_hwnd_child)
	{
		Error ("Control window handle has not been set");
		return 0;
	}

	hitem = (HTREEITEM)SendMessage (m_hwnd_child, TVM_GETNEXTITEM, TVGN_CARET, 0);
	if (! hitem)
	{
		Error ("GetTreeViewItemImageIx, TVM_GETNEXTITEM, TVGN_CARET failed");
		return E_FAIL;
	}

	item.hItem = hitem;
	item.mask |= TVIF_HANDLE;
#if 0
	item.mask |= TVIF_TEXT;
	item.pszText = buf;
//	item.cchTextMax = sizeof(buf);
	item.cchTextMax = sizeof(buf) / sizeof(buf[0]);
#endif
#if 0
	item.mask |= TVIF_STATE;
// checkbox state is defined by the index of image
	item.stateMask = TVIS_STATEIMAGEMASK;
	item.stateMask = 0xffff;
#endif
#if 0
	item.mask |= TVIF_IMAGE;
	item.mask |= TVIF_PARAM;
	item.mask |= TVIF_SELECTEDIMAGE;
	item.mask |= TVIF_CHILDREN;
	item.mask |= TVIF_INTEGRAL;
#endif
	item.mask |= TVIF_IMAGE;

	r = SendMessage_TVM_GETITEMW (item);
	if (! r)
		return E_FAIL;

//	*image_ix = item.iImage;
// free what there was
// **will this cause no leaks ?
	VariantClear (image_ix);
// good
//	V_VT(image_ix) = VT_BOOL;
//	V_BOOL(image_ix) = item.iImage;
// unsupported in VBS
//	V_VT(image_ix) = VT_UI4;
//	V_UI4(image_ix) = item.iImage;
// good
	V_VT(image_ix) = VT_I4;
	V_I4(image_ix) = item.iImage;

#if 0
	Error ("-----");
	return E_FAIL;
#endif

	return S_OK;
}

STDMETHODIMP CWndCtrls::GetListViewItemImageIx(VARIANT *image_ix)
{
	bool r;
	LVITEMW item = {0};
	wchar_t buf[256] = L"<unset>";
	u32 item_ix;

	if (! m_hwnd_child)
	{
		Error ("Control window handle has not been set");
		return E_FAIL;
	}

// test
#if 0
	u32 item_count;
	item_count = SendMessage (m_hwnd_child, LVM_GETITEMCOUNT, 0, 0);
	swprintf (buf, L"item_count is %u", item_count);
	Error (buf);
	return E_FAIL;
#endif
// 0
#if 0
	u32 item_count;
	item_count = SendMessage (m_hwnd_child, LVM_GETSELECTEDCOUNT, 0, 0);
	swprintf (buf, L"selected items count is %u", item_count);
	Error (buf);
	return E_FAIL;
#endif

//	item_ix = SendMessage (m_hwnd_child, LVM_GETNEXTITEM, -1, MAKELPARAM(LVNI_FOCUSED, 0));
	item_ix = SendMessage (m_hwnd_child, LVM_GETNEXTITEM, -1, MAKELPARAM(LVNI_ALL | LVNI_FOCUSED, 0));
// fails
//	item_ix = SendMessage (m_hwnd_child, LVM_GETNEXTITEM, -1, MAKELPARAM(LVNI_BELOW | LVNI_FOCUSED, 0));
// fails
//	item_ix = SendMessage (m_hwnd_child, LVM_GETNEXTITEM, -1, MAKELPARAM(LVNI_SELECTED, 0));
	if (item_ix == -1)
	{
		Error ("GetListViewItemImageIx, LVM_GETNEXTITEM, LVNI_FOCUSED failed");
		return E_FAIL;
	}
// test
#if 0
	swprintf (buf, L"item_ix is %u", item_ix);
	Error (buf);
	return E_FAIL;
#endif

// test
	item_ix = 7;

	item.iItem = item_ix;
// test
#if 0
	item.mask |= LVIF_TEXT;
	item.pszText = buf;
	item.cchTextMax = sizeof(buf) / sizeof(buf[0]);
#endif
#if 1
	item.mask |= TVIF_STATE;
// checkbox state is defined by the index of image
	item.stateMask = LVIS_STATEIMAGEMASK;
	item.stateMask = 0xffff;
#endif
	item.mask |= TVIF_IMAGE;

	r = SendMessage_LVM_GETITEMW (item);
	if (! r)
		return E_FAIL;

	V_VT(image_ix) = VT_I4;
	V_I4(image_ix) = item.iImage;

// test
#if 0
//	Error ("-----");
	Error (buf);
	return E_FAIL;
#endif
// 0
#if 0
	swprintf (buf, L"state is %08x", item.state);
	Error (buf);
	return E_FAIL;
#endif
// cccccccc
#if 0
	swprintf (buf, L"image ix is %08x", item.iImage);
	Error (buf);
	return E_FAIL;
#endif

	return S_OK;
}
